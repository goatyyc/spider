import csv
import requests
from lxml import etree
import time
headers  ={
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36'
}
base_url = 'https://www.yanglao.com.cn'
file = open('data.csv', 'a+', encoding='utf-8', newline='')

# 封装获取单页面信息函数
def get_one(url):
    time.sleep(4)
    response = requests.get(url, headers=headers).text
    tree = etree.HTML(response)

    # 获取所有Li
    lis = tree.xpath('//div[@class="panel"]/div[@class="base-info"]/div[@class="cont"]//li')
    dic = {}
    # 字典中添加机构名称、地址
    try:
        name = tree.xpath('//div[@class="cont"]/div[@class="inst-summary"]/h1/text()')
        name = name[0].replace(" ", "").replace("\n", "")
        place = tree.xpath('//div[@class="cont"]/div[@class="inst-summary"]/ul/li[1]/text()')       # /html/body/div[5]/div[1]/div[1]/div/div[2]/ul/li[1]/text()
        place = place[0]
        dic['机构名称'] = name
        dic['地址'] = place
    except:
        pass
    for li in lis:
        try:
            data = li.xpath('./text()')
            # print(data)
            title = li.xpath('./em/text()')
            title = title[0].replace('：', '')

            data = data[0].replace(" ","").replace("\n", "").split()
            if '-' in data[0]:
                data = data[0].split('-')
            # 封装字典
            dic[title] = data
        except:
            continue
    # 处理字典，拷贝字典key

    for key in list(dic):
        try:
        # print(key, '---', dic[key])
            if key == '收费区间':
                dic['收费下线'] = dic[key][0]
                dic['收费上线'] = dic[key][1]
            if key == '收住对象':
                for i in range(len(dic[key])):
                    dic[dic[key][i]] = dic[key][i]
            if key == '所在地区':
                    dic['省级'] = dic[key][0]
                    dic['市级'] = dic[key][1]
                    dic['区级'] = dic[key][2]
                
            if key == '特色服务':
                for i in range(len(dic[key])):
                    dic[dic[key][i]] = dic[key][i]
        except:
                continue

    # 按顺序写入列表
    '''
    '机构名称',	'地址',	'省级', '市级', '区级', '机构类型',	
    '机构性质',	'成立时间', '占地面积',	'床位数',	
    '收费下线',	'收费上线', '自理',	'半自理/介助',
    '不能自理/介护', '特护', '认知障碍', '短住旅居', 
    '可接收异地老人', '具备医保定点资格'
    '''
    ls = ['机构名称',	'地址',	'省级', '市级', '区级', '机构类型',	
        '机构性质',	'成立时间', '占地面积',	'床位数',	
        '收费下线',	'收费上线', '自理',	'半自理/介助',
        '不能自理/介护', '特护', '认知障碍', '短住旅居', 
        '可接收异地老人', '具备医保定点资格']
    ls_len = len(ls)
    res = list()

    # 思路：写入csv的列表按ls的顺序，遍历字典，如果字典中存在则加入，不存在则加“none”
    for item in ls:
        # print(item)
        for key in dic:
            # print(key)
            if key == item:
                if type(dic[key]) is list:
                    res.append(dic[key][0])
                else:
                    res.append(dic[key])
                dic.pop(key)
                break
        else:       # break执行后，则else不执行
            res.append("none")
    
    # 写入csv
    csv_writer = csv.writer(file)
    csv_writer.writerow(res)
    # return res

# 封装获取单页url
def get_one_page(page_url):
    time.sleep(3)
    response = requests.get(page_url, headers = headers).text
    html = etree.HTML(response)
    lis = html.xpath('//div[@class="list-view"]/ul[@class="rest-items"]/li[@class="rest-item"]')
    ls = []
    for li in lis:
        href = li.xpath('./a/@href')
        detail_url = base_url+href[0]
        print(detail_url)
        get_one(detail_url)
        ls.append(detail_url)
        # print(url)
    # print(base_url+res[0])
    # return ls


def get_all(page):
    base = 'https://www.yanglao.com.cn/resthome'
    time.sleep(1)
    for i in range(850,page):
        
        time.sleep(2)
        url = base+'_'+str(i)
        get_one_page(url)
    



if __name__ == "__main__":
    # url = 'https://www.yanglao.com.cn/resthome/19516.html'      # https://www.yanglao.com.cn/resthome/resthome/1244732.html
    # res = get_one(url)
    # start_time = time.time()
    # get_one_page('https://www.yanglao.com.cn/resthome_100')
    # end_time = time.time()

    # time.sleep(0.5)
    # print("耗时共：%d 秒"%(end_time-start_time))
    get_all(925)