# 导入requests包
import requests
from lxml import etree
import csv
import codecs
# 请求头
headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36"
    }



# 获取单页信息
def get_single_page(url):
    res = requests.get(url, headers=headers)
    res.encoding='gbk'
    s = res.text

    selector = etree.HTML(s)

    for item in selector.xpath('/html/body/div[4]/div[2]/div[1]/div/div'):
        title = item.xpath('.//p/span[@class="title"]/a/text()')    # 职位名称
        name = item.xpath('.//p/a/@title')                          # 公司名称
        location_name = item.xpath('.//p/span[@class="location name"]/text()')      # 地址
        sary = item.xpath('.//p/span[@class="location"]/text()')                    # 薪水
        time = item.xpath('.//p/span[@class="time"]/text()')                        # 日期
        edu = item.xpath('.//p[@class="order"]/text()[1]')                          # 学历
        experience = item.xpath('.//p[@class="order"]/text()[2]')                          # 工作经验
        properties = item.xpath('.//p[@class="order"]/text()[3]')                          # 公司性质
        scale = item.xpath('.//p[@class="order"]/text()[4]')                          # 公司规模
        breif = item.xpath('.//p[@class="text"]/@title')                          # 岗位描述


        if len(title)>0:
            print(title)
            print(name)
            print(location_name)
            print(sary)
            print(time)
            print(edu)
            print(experience)
            print(properties)
            print(scale)
            print(breif)
            print("-----------")

            # 存储为csv
            try:
                with open('data.csv', 'a', newline='', encoding='utf-8-sig') as file_csv:
                        csv_writer = csv.writer(file_csv, dialect='excel')
                        csv_writer.writerow([title[0], breif[0], name[0], properties[0], "nah", "nah", sary[0], location_name[0], "nah", time[0], scale[0], edu[0], experience[0]])
            except:
                continue

# 遍历页面
def get_pages():
    url = "https://jobs.51job.com/pachongkaifa/p"

    page = 13
    for i in range(page):
        new_url = url+str(i+1)+'/'
        get_single_page(new_url)

if __name__ == "__main__":
    # 写入csv文件首行
    with open('data.csv', 'w', newline='', encoding='utf-8-sig') as file_csv:
        csv_writer = csv.writer(file_csv, dialect='excel')
        csv_writer.writerow(["职位名称","职位详情","公司名称","公司类型","公司主营","公司详情","薪资","工作地点","更新日期","发布日期","公司规模","学历要求","工作经验"])

    get_pages()