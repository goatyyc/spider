import re
import time
import requests
import csv

# 封装请求头函数
def get_headers(url):
    requests_headers = {
        'Referer': url,  # 3474,不加referer会失败
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'
    }

    return requests_headers


# 定义抓取单个景点评论的函数
def get_one_spot(url, requests_headers, filename, id):
    for num in range(1, 15):
        requests_data = {
            # 经过测试只需要用params参数就能爬取内容
            'params': '{"poi_id":"%d","page":"%d","just_comment":1}' % (id, num)
        }
        response = requests.get(
            url=comment_url,
            headers=requests_headers,
            params=requests_data)
        if 200 == response.status_code:
            page = response.content.decode(
                'unicode-escape',
                'ignore').encode(
                'utf-8',
                'ignore').decode('utf-8')  # 爬取页面并且解码
            page = page.replace('\\/', '/')  # 将\/转换成/

            # 用户列表
            user_pattern = r'<a class="name".*?>([\s\S]*?)</a>'
            user_list = re.compile(user_pattern).findall(page)
            # 日期列表
            date_pattern = r'<a class="btn-comment _j_comment" title="添加评论">评论</a>.*?\n.*?<span class="time">(.*?)</span>'
            date_list = re.compile(date_pattern).findall(page)
            # 星级列表
            star_pattern = r'<span class="s-star s-star(\d)"></span>'
            star_list = re.compile(star_pattern).findall(page)
            # 评论列表
            comment_pattern = r'<p class="rev-txt">([\s\S]*?)</p>'
            comment_list = re.compile(comment_pattern).findall(page)
            for num in range(0, len(date_list)):
                # 用户
                user = user_list[num]
                # 日期
                date = date_list[num]
                # 星级评分
                star = star_list[num]
                # 评论内容，处理一些标签和符号
                comment = comment_list[num]
                comment = str(comment).replace('&nbsp;', '')
                comment = comment.replace('<br>', '')
                comment = comment.replace('<br />', '')
                print(user + "\t" + date + "\t" + star + "\t" + comment)
                # 写入csv
                with open(filename, 'a+', encoding='utf-8') as file:
                    writer = csv.writer(file, dialect="excel")
                    writer.writerow([user, star])
        else:
            print("爬取失败")
    return

# 获取所有景点相关url
def get_url():
    # 故宫3474、八达岭长城3519、天坛公园3503、颐和园3557、圆明园6427
    ids = ['3474', '3519', '3503', '3557', '6427']
    urls = []
    for id in ids:
        url = "https://www.mafengwo.cn/poi/"+id+".html"
        urls.append(url)
    return urls


if __name__ == '__main__':
    # 评论内容所在的url，？后面是get请求需要的参数内容
    comment_url = 'http://pagelet.mafengwo.cn/poi/pagelet/poiCommentListApi?'
    # get_one_spot(comment_url)
    # 循环获取请求头和url
    urls = get_url()
    ids = ['3474', '3519', '3503', '3557', '6427']
    location = ["故宫", "八达岭长城", "天坛公园", "颐和园", "圆明园"]
    for i in range(len(urls)):
        id = int(ids[i])
        url = urls[i]
        print(url)
        headers = get_headers(url)
        filename = location[i]+'.csv'
        print(filename)
        get_one_spot(url, headers, filename, id)

