# 柱状图
# Matplotlib绘制全国各地区的确诊人数柱状图
from pyecharts import options as opts
from pyecharts.charts import Bar
from pyecharts.faker import Faker



import pandas as pd
# data = pd.read_excel(r'data.xlsx')
# arrt = data['省份'].values
# lis = data['累计确诊'].values[0]
# print(arrt)

# print(lis)

df = pd.read_excel("data.xlsx", usecols=[0],
                       names=None)  # 读取项目名称列,不要列名
df_li = df.values.tolist()
# arrt横坐标
arrt = []
for ls in df_li:
    arrt.append(ls[0])


df2 = pd.read_excel("data.xlsx", usecols=[1],
                       names=None)  # 读取项目名称列,不要列名
df_li = df2.values.tolist()

# 纵坐标lists
lis = []
for li in df_li:
    lis.append(li[0])


c = (
    Bar()
    .add_xaxis(arrt)
    .add_yaxis("地区疫情柱状图", lis, color=Faker.rand_color())
    .set_global_opts(
        title_opts=opts.TitleOpts(title="Bar-DataZoom（slider+inside）"),
        datazoom_opts=[opts.DataZoomOpts(), opts.DataZoomOpts(type_="inside")],
    )
    .render("bar_datazoom_both.html")
)