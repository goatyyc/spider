# 爬取淘宝网信息
from selenium import webdriver
import csv
import time
# 获取商品信息
def get_product():
    lis = driver.find_elements_by_xpath('//*[@id="mx_5"]/ul/li')
    
    for li in lis:
        intro = li.find_element_by_xpath('.//div[@class="pc-items-item-title pc-items-item-title-row2"]/span').text   # 简介
        price = li.find_element_by_xpath('.//div[@class="price-con"]/span[3]').text    # 价格
        store_name = li.find_element_by_xpath('.//div[@class="seller-info"]//div').text.strip('')    # 店铺名称
        sales = li.find_element_by_xpath('.//div[@class="item-footer"]//div[@class="sell-info"]').text    # 月销量
        print(intro, price, store_name, sales, sep='|')
        # 保存到csv
        with open('data.csv', 'a', newline='', encoding='utf-8') as file_csv:
            csv_writer = csv.writer(file_csv, dialect='excel')
            csv_writer.writerow([intro, price, store_name, sales])


# 分页跳转
# def redirect_page():

'''
url变化 
https://uland.taobao.com/sem/tbsearch?refpid=mm_26632258_3504122_32538762&keyword=%E7%BE%8E%E9%A3%9F&clk1=b29eef40048298509b77ce912e3dc958&upsId=b29eef40048298509b77ce912e3dc958&spm=a2e0b.20350158.search.1&pid=mm_26632258_3504122_32538762&union_lens=recoveryid%3A201_11.8.41.229_1844976_1608984929272%3Bprepvid%3A201_11.8.41.229_1844976_1608984929272

https://uland.taobao.com/sem/tbsearch?refpid=mm_26632258_3504122_32538762&keyword=%E7%BE%8E%E9%A3%9F&clk1=b29eef40048298509b77ce912e3dc958&upsId=b29eef40048298509b77ce912e3dc958&spm=a2e0b.20350158.31919782.1&pid=mm_26632258_3504122_32538762&union_lens=recoveryid%3A201_11.8.41.229_1844976_1608984929272%3Bprepvid%3A201_11.8.41.229_1844976_1608984929272&pnum=1
a
https://uland.taobao.com/sem/tbsearch?refpid=mm_26632258_3504122_32538762&keyword=%E7%BE%8E%E9%A3%9F&clk1=b29eef40048298509b77ce912e3dc958&upsId=b29eef40048298509b77ce912e3dc958&spm=a2e0b.20350158.31919782.1&pid=mm_26632258_3504122_32538762&union_lens=recoveryid%3A201_11.8.41.229_1844976_1608984929272%3Bprepvid%3A201_11.8.41.229_1844976_1608984929272&pnum=2
'''
# 搜索商品
def search_product(key):
    input_box = driver.find_element_by_id('J_search_key')
    
    # 清空输入框
    input_box.clear()

    input_box.send_keys(key)
    
    # driver.find_element_by_id('J_search_key').send_keys(key)
    driver.find_element_by_xpath('//*[@id="J_searchForm"]/input').click()
    driver.maximize_window()
    time.sleep(5)

    # 找页数总数标签 (暂无)
    # page = driver.find_element_by_xpath()

def main(page):
    # 获取当前url
    current_url = driver.current_url
    # print(current_url)
    # print("正在爬取第1页数据")
    page_num = 0
    while page_num < int(page):
        print('*'*100)
        print('正在爬取第{}页的数据'.format(page_num+1))

        url = current_url+'&pnum='+str(page_num)
        # print(url)

        driver.get(url)
        driver.implicitly_wait(1)   #浏览器等待
        driver.maximize_window()    #最大化浏览器
        get_product()
        page_num +=  1

if __name__ == '__main__':
    key = input("输入商品：")
    page = input("爬取页数：")
    driver = webdriver.Chrome()
    driver.get("https://uland.taobao.com/sem/tbsearch?refpid=mm_26632258_3504122_32538762&keyword=%E5%A5%B3%E8%A3%85&clk1=b29eef40048298509b77ce912e3dc958&upsId=b29eef40048298509b77ce912e3dc958")
    search_product(key)
    main(page)