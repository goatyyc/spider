# 获取单词函数定义
def get_txt(filename):
    txt = open(filename, encoding='utf8').read()
    txt = txt.lower()
    for ch in '!"@#$%^&*()+,-./:;<=>?@[\\]_`~{|}123456780':  # 替换特殊字符
        txt = txt.replace(ch, ' ')
    return txt[1:]
# 获取单词
text_word = get_txt('ttt.txt').split()
# 六级单词表
etc = get_txt('six_word.txt').split()
# 遍历统计
counts = {}
for word in text_word:
    if word in etc:  # 判断单词是否在六级词汇中，若在key值加一
        counts[word] = counts.get(word, 0) + 1  # 字典的get()方法，dict.get(key, default=None)

# 转换格式，方便打印，将字典转换为列表
countsList = list(counts.items())

# countsList.sort(key=lambda x: x[1], reverse=True)  # 按次数从大到小排序

# # 打印
# for i in range(100):
#     word, count = countsList[i]
#     print('{0:<10}{1:>5}'.format(word, count))
