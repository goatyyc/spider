# 获取单词函数
def get_txt(filename):
    txt = open(filename, encoding='utf8').read()
    txt = txt.lower()
    for ch in '!"@#$%^&*()+,-./:;<=>?@[\\]_`~{|}123456780》《':  # 替换特殊字符
        txt = txt.replace(ch, ' ')
    return txt[1:]

# 获取单词 
text_word = get_txt('article.txt').split()      
dic = {}

words = get_txt('article.txt').split()
# 去重
ls = []
for word in words:
    if word not in ls:
        ls.append(word)

# 遍历清洗后的文本
counts = {}
times = 0
for word in text_word:
    if word in ls:
        counts[word] = counts.get(word, 0)+1    # 字典的get()方法，dict.get(key, default=None)
    # 统计单词长度为4的个数
    if len(word) == 4:
        times += 1
countsList = list(counts.items())

countsList.sort(key=lambda x: x[1], reverse=True)  # 按次数从大到小排序

# 打印前二十个
print("次数出现最多的20个单词：")
for i in range(20):
    word, count = countsList[i]
    print('{0:<10}{1:>5}'.format(word, count))

print("单词长度为4的单词个数共有：%d个"%times)